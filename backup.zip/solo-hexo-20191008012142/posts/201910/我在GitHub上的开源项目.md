title: 我在 GitHub 上的开源项目
date: '2019-10-06 01:11:44'
updated: '2019-10-06 01:11:44'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [face_pro](https://github.com/reventhao/face_pro) <kbd title="主要编程语言">Tcl</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/reventhao/face_pro/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/reventhao/face_pro/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/reventhao/face_pro/network/members "分叉数")</span>

face_pro



---

### 2. [face_recognition_util](https://github.com/reventhao/face_recognition_util) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/reventhao/face_recognition_util/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/reventhao/face_recognition_util/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/reventhao/face_recognition_util/network/members "分叉数")</span>

face_recognition_util



---

### 3. [k-yinhang](https://github.com/reventhao/k-yinhang) <kbd title="主要编程语言">TypeScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/reventhao/k-yinhang/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/reventhao/k-yinhang/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/reventhao/k-yinhang/network/members "分叉数")</span>





---

### 4. [sfedu](https://github.com/reventhao/sfedu) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/reventhao/sfedu/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/reventhao/sfedu/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/reventhao/sfedu/network/members "分叉数")</span>

edu project of sf



---

### 5. [reTz](https://github.com/reventhao/reTz) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/reventhao/reTz/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/reventhao/reTz/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/reventhao/reTz/network/members "分叉数")</span>



